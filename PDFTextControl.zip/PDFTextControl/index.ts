import { IInputs, IOutputs } from "./generated/ManifestTypes";

interface PDFJSStatic {
    getDocument: (url: string) => { promise: Promise<PDFDocumentProxy> };
    GlobalWorkerOptions: {
        workerSrc: string;
    };
    renderTextLayer: (params: {
        textContent: TextContent;
        container: HTMLElement;
        viewport: PDFPageViewport;
        textDivs: HTMLElement[];
        enhanceTextSelection?: boolean;
    }) => Promise<void> | void;
}

interface PDFDocumentProxy {
    numPages: number;
    getPage(pageNumber: number): Promise<PDFPageProxy>;
}

interface PDFPageProxy {
    getViewport(params: { scale: number }): PDFPageViewport;
    render(params: { canvasContext: CanvasRenderingContext2D; viewport: PDFPageViewport }): { promise: Promise<void> };
    getTextContent(): Promise<TextContent>;
}

interface PDFPageViewport {
    width: number;
    height: number;
}

interface TextItem {
    str: string;
}

interface TextContent {
    items: TextItem[];
}

declare const window: Window & {
    pdfjsLib?: PDFJSStatic;
};

export class PDFTextControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container!: HTMLDivElement;
    private pdfUrl = "https://raw.githubusercontent.com/calok64/powerappsdemo/main/sample%20PO.pdf";

    private selectedTextBox!: HTMLInputElement;
    private searchTextBox!: HTMLInputElement;
    private pdfContainer!: HTMLDivElement;

    private pdfDoc?: PDFDocumentProxy;
    private scale = 1.0;

    public async init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): Promise<void> {
        this.container = container;
        await this.loadPdfJs();

        this.selectedTextBox = this.createInput("Selected text will appear here...", true);
        this.searchTextBox = this.createInput("Enter text to highlight...", false);
        this.searchTextBox.addEventListener("input", () => {
            this.highlightText(this.searchTextBox.value);
        });

        const wrapper = document.createElement("div");
        Object.assign(wrapper.style, {
            width: "100%",
            height: "600px",
            overflow: "auto",
            border: "1px solid #ccc",
            position: "relative"
        });

        this.pdfContainer = document.createElement("div");
        Object.assign(this.pdfContainer.style, {
            width: "100%",
            height: "auto",
            position: "relative"
        });

        this.pdfContainer.addEventListener("mouseup", () => {
            const selectedText = window.getSelection()?.toString() ?? "";
            this.selectedTextBox.value = selectedText;
        });

        wrapper.appendChild(this.pdfContainer);
        this.container.appendChild(this.selectedTextBox);
        this.container.appendChild(this.searchTextBox);
        this.container.appendChild(wrapper);

        await this.loadAndRenderPDF(this.pdfUrl);
    }

    private createInput(placeholder: string, readOnly: boolean): HTMLInputElement {
        const input = document.createElement("input");
        input.type = "text";
        input.placeholder = placeholder;
        input.readOnly = readOnly;
        Object.assign(input.style, {
            width: "100%",
            marginBottom: "10px",
            padding: "8px",
            boxSizing: "border-box"
        });
        return input;
    }

    private async loadPdfJs(): Promise<void> {
        return new Promise((resolve, reject) => {
            if (window.pdfjsLib) {
                resolve();
                return;
            }

            const script = document.createElement("script");
            script.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js";
            script.onload = (): void => {
                if (!window.pdfjsLib) {
                    reject("pdfjsLib did not load correctly");
                    return;
                }
                window.pdfjsLib.GlobalWorkerOptions.workerSrc =
                    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js";
                resolve();
            };
            script.onerror = (): void => reject("Failed to load pdf.js script");
            document.head.appendChild(script);
        });
    }

    private async loadAndRenderPDF(url: string): Promise<void> {
        if (!window.pdfjsLib) return;

        this.pdfDoc = await window.pdfjsLib.getDocument(url).promise;
        this.pdfContainer.innerHTML = ""; // Clear previous renderings

        for (let pageNum = 1; pageNum <= this.pdfDoc.numPages; pageNum++) {
            const page = await this.pdfDoc.getPage(pageNum);
            const viewport = page.getViewport({ scale: this.scale });

            const pageDiv = document.createElement("div");
            pageDiv.style.position = "relative";
            pageDiv.style.marginBottom = "10px";

            const canvas = document.createElement("canvas");
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            canvas.style.display = "block";
            pageDiv.appendChild(canvas);

            const ctx = canvas.getContext("2d");
            if (!ctx) throw new Error("Failed to get 2D context for canvas");

            await page.render({ canvasContext: ctx, viewport }).promise;

            const textLayerDiv = document.createElement("div");
            textLayerDiv.className = "textLayer";
            Object.assign(textLayerDiv.style, {
                position: "absolute",
                top: "0",
                left: "0",
                height: `${viewport.height}px`,
                width: `${viewport.width}px`,
                pointerEvents: "auto",
                userSelect: "text",
                color: "black",               // Visible text for selection
                backgroundColor: "transparent",
                fontSize: "10px",             // Optional: control text size
                lineHeight: "1",
                mixBlendMode: "multiply",     // Blend text with canvas beneath
            });

            pageDiv.appendChild(textLayerDiv);

            const textContent = await page.getTextContent();

            await window.pdfjsLib.renderTextLayer({
                textContent,
                container: textLayerDiv,
                viewport,
                textDivs: [],
                enhanceTextSelection: true
            });

            this.pdfContainer.appendChild(pageDiv);
        }

        this.highlightText(this.searchTextBox.value);
    }

    private highlightText(searchTerm: string): void {
        const textLayers = this.pdfContainer.querySelectorAll(".textLayer");

        // Remove old highlights
        textLayers.forEach(layer => {
            layer.querySelectorAll("span.highlight").forEach(span => {
                const parentNode = span.parentNode;
                if (!parentNode) return;
                parentNode.replaceChild(document.createTextNode(span.textContent || ""), span);
                parentNode.normalize();
            });
        });

        if (!searchTerm.trim()) return;

        const regex = new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), "gi");

        function highlightMatchesInNode(node: Node): void {
            if (node.nodeType === Node.TEXT_NODE) {
                const text = node.textContent ?? "";
                const matches = [...text.matchAll(regex)];
                if (matches.length === 0) return;

                const frag = document.createDocumentFragment();
                let lastIndex = 0;

                for (const match of matches) {
                    const start = match.index ?? 0;
                    const end = start + match[0].length;

                    if (start > lastIndex) {
                        frag.appendChild(document.createTextNode(text.substring(lastIndex, start)));
                    }

                    const highlightSpan = document.createElement("span");
                    highlightSpan.className = "highlight";
                    Object.assign(highlightSpan.style, {
                        border: "1px solid red",
                        padding: "0 2px",
                        borderRadius: "2px",
                        backgroundColor: "yellow"
                    });
                    highlightSpan.textContent = text.substring(start, end);
                    frag.appendChild(highlightSpan);

                    lastIndex = end;
                }

                if (lastIndex < text.length) {
                    frag.appendChild(document.createTextNode(text.substring(lastIndex)));
                }

                node.parentNode?.replaceChild(frag, node);
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                Array.from(node.childNodes).forEach(child => highlightMatchesInNode(child));
            }
        }

        textLayers.forEach(layer => {
            highlightMatchesInNode(layer);
        });
    }

    public updateView(_context: ComponentFramework.Context<IInputs>): void {
        // No updates needed currently
    }

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {
        [this.selectedTextBox, this.searchTextBox, this.pdfContainer].forEach(el => {
            if (el && this.container.contains(el)) {
                this.container.removeChild(el);
            }
        });
    }
}
